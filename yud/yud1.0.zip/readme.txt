   yud(Yuroyumachi's Utilities Distribution) 1.0
   -----------------------------------------------

   This is a portable development environment for Windows x86_64

   Everything here was compiled with TinyCC:
      busybox
      make
      lua
      tcc

   Getting started:
      - Extract yud.zip.
      - Run yud.bat to start yud.

   Disclaimer:

   USE AT YOUR OWN RISK.

have fun with yud if you like.
Nov. 24 2026 --- Yuroyumachi