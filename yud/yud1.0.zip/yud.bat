@echo OFF

setlocal
set "YUD=%~dp0"
if "%YUD:~-1%"=="\" set "YUD=%YUD:~0,-1%"

set "PATH=%YUD%\gmake;%YUD%\lua;%YUD%\tcc;%PATH%"

"%YUD%\busybox\sh.exe" %*
goto :eof